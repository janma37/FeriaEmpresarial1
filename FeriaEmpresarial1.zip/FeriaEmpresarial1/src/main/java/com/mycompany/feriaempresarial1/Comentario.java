/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Comentario {
    private String nombreVisitante;
    private LocalDate fecha;
    private int calificacion; // 1 a 5
    private String texto;

    public Comentario(String nombreVisitante, int calificacion, String texto) {
        this.nombreVisitante = nombreVisitante;
        this.fecha = LocalDate.now();
        this.calificacion = calificacion;
        this.texto = texto;
    }

    public String mostrarDetalles() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String estrellas = "⭐".repeat(calificacion);
        return String.format("  - [%s] %s (%s): %s",
                this.fecha.format(formatter),
                this.nombreVisitante,
                estrellas,
                this.texto);
    }
}
