/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
import java.util.ArrayList;
import java.util.List;

public class Stand {
    private int numeroUnico;
    private String ubicacion;
    private String tamano; // pequeño, mediano, grande
    private Empresa empresaAsignada;
    private List<Comentario> comentarios;

    public Stand(int numeroUnico, String ubicacion, String tamano) {
        this.numeroUnico = numeroUnico;
        this.ubicacion = ubicacion;
        this.tamano = tamano;
        this.empresaAsignada = null; // Inicia disponible
        this.comentarios = new ArrayList<>();
    }

    // Getters
    public int getNumeroUnico() { return numeroUnico; }
    public Empresa getEmpresaAsignada() { return empresaAsignada; }

    public boolean estaOcupado() {
        return this.empresaAsignada != null;
    }

    public void asignarEmpresa(Empresa empresa) {
        this.empresaAsignada = empresa;
    }

    public void liberarStand() {
        this.empresaAsignada = null;
    }

    public void agregarComentario(Comentario comentario) {
        this.comentarios.add(comentario);
    }

    public String mostrarDetalles() {
        String estado = estaOcupado() ? "Ocupado por: " + empresaAsignada.getNombre() : "Estado: Disponible";
        return String.format("Stand N°: %d | Ubicacion: %s | Tamaño: %s | %s",
                this.numeroUnico, this.ubicacion, this.tamano, estado);
    }

    public void mostrarComentarios() {
        if (comentarios.isEmpty()) {
            System.out.println("  No hay comentarios para este stand.");
        } else {
            System.out.println("  Comentarios del Stand N°" + this.numeroUnico + ":");
            for (Comentario c : comentarios) {
                System.out.println(c.mostrarDetalles());
            }
        }
    }
}