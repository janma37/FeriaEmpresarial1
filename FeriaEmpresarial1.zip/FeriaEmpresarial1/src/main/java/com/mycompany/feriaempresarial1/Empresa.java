/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
public class Empresa {
    private static int contadorId = 1;
    private int id;
    private String nombre;
    private String sector;
    private String email;

    public Empresa(String nombre, String sector, String email) {
        this.id = contadorId++;
        this.nombre = nombre;
        this.sector = sector;
        this.email = email;
    }

    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getSector() { return sector; }
    public String getEmail() { return email; }

    // Setters para editar
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setSector(String sector) { this.sector = sector; }
    public void setEmail(String email) { this.email = email; }

    public String mostrarDetalles() {
        return String.format("ID: %d | Empresa: %s | Sector: %s | Email: %s",
                this.id, this.nombre, this.sector, this.email);
    }
}
