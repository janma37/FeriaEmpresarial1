/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class FeriaManager {
    private List<Empresa> empresas = new ArrayList<>();
    private List<Stand> stands = new ArrayList<>();
    private List<Visitante> visitantes = new ArrayList<>();
    
    // Métodos para Empresas
    public void registrarEmpresa(String nombre, String sector, String email) {
        empresas.add(new Empresa(nombre, sector, email));
    }
    public Empresa buscarEmpresa(int id) {
        return empresas.stream().filter(e -> e.getId() == id).findFirst().orElse(null);
    }
    public boolean eliminarEmpresa(int id) {
        Empresa empresa = buscarEmpresa(id);
        if (empresa != null) {
            // Liberar stand si lo tenia asignado
            stands.stream()
                  .filter(s -> s.getEmpresaAsignada() == empresa)
                  .forEach(Stand::liberarStand);
            return empresas.remove(empresa);
        }
        return false;
    }

    // Métodos para Stands
    public void crearStand(int numero, String ubicacion, String tamano) {
        stands.add(new Stand(numero, ubicacion, tamano));
    }
    public Stand buscarStand(int numero) {
        return stands.stream().filter(s -> s.getNumeroUnico() == numero).findFirst().orElse(null);
    }
    public List<Stand> getStandsDisponibles() {
        return stands.stream().filter(s -> !s.estaOcupado()).collect(Collectors.toList());
    }
    public List<Stand> getStandsOcupados() {
        return stands.stream().filter(Stand::estaOcupado).collect(Collectors.toList());
    }
    
    // Métodos para Visitantes
    public void registrarVisitante(String nombre, String id, String email) {
        visitantes.add(new Visitante(nombre, id, email));
    }
    public Visitante buscarVisitante(String id) {
        return visitantes.stream().filter(v -> v.getNumeroIdentificacion().equals(id)).findFirst().orElse(null);
    }
    public boolean eliminarVisitante(String id) {
        return visitantes.removeIf(v -> v.getNumeroIdentificacion().equals(id));
    }

    // Métodos de Interacción
    public boolean asignarEmpresaAStand(int idEmpresa, int numStand) {
        Empresa empresa = buscarEmpresa(idEmpresa);
        Stand stand = buscarStand(numStand);
        if (empresa != null && stand != null && !stand.estaOcupado()) {
            stand.asignarEmpresa(empresa);
            return true;
        }
        return false;
    }

    public boolean registrarVisitaYComentario(String idVisitante, int numStand, int calificacion, String texto) {
        Visitante visitante = buscarVisitante(idVisitante);
        Stand stand = buscarStand(numStand);
        if (visitante != null && stand != null && stand.estaOcupado()) {
            visitante.visitarStand(stand);
            Comentario comentario = new Comentario(visitante.getNombre(), calificacion, texto);
            stand.agregarComentario(comentario);
            return true;
        }
        return false;
    }

    // Métodos de Reportes
    public void generarReporteEmpresasYStands() {
        System.out.println("\n--- Reporte: Empresas y Stands Asignados ---");
        if(empresas.isEmpty()){
            System.out.println("No hay empresas registradas.");
            return;
        }
        for (Empresa e : empresas) {
            Stand standAsignado = stands.stream()
                                        .filter(s -> s.getEmpresaAsignada() == e)
                                        .findFirst()
                                        .orElse(null);
            String infoStand = (standAsignado != null) ? "Asignada al Stand N°" + standAsignado.getNumeroUnico() : "Sin stand asignado";
            System.out.println(e.mostrarDetalles() + " -> " + infoStand);
        }
    }

    public void generarReporteVisitantesYVisitas() {
        System.out.println("\n--- Reporte: Visitantes y Stands Visitados ---");
        if(visitantes.isEmpty()){
            System.out.println("No hay visitantes registrados.");
            return;
        }
        for (Visitante v : visitantes) {
            System.out.println(v.mostrarDetalles());
            if (v.getStandsVisitados().isEmpty()) {
                System.out.println("  - No ha visitado ningun stand.");
            } else {
                for (Stand s : v.getStandsVisitados()) {
                    System.out.println("  - Visito Stand N°" + s.getNumeroUnico() + " (" + s.getEmpresaAsignada().getNombre() + ")");
                }
            }
        }
    }
    
    // Getters para listas completas (usados por la UI)
    public List<Empresa> getEmpresas() { return empresas; }
    public List<Stand> getStands() { return stands; }
    public List<Visitante> getVisitantes() { return visitantes; }
}
