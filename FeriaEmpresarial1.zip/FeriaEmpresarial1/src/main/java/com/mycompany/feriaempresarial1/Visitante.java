/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
import java.util.ArrayList;
import java.util.List;

public class Visitante {
    private String numeroIdentificacion; // Sera el ID unico
    private String nombre;
    private String email;
    private List<Stand> standsVisitados;

    public Visitante(String nombre, String numeroIdentificacion, String email) {
        this.nombre = nombre;
        this.numeroIdentificacion = numeroIdentificacion;
        this.email = email;
        this.standsVisitados = new ArrayList<>();
    }
    
    // Getters
    public String getNumeroIdentificacion() { return numeroIdentificacion; }
    public String getNombre() { return nombre; }
    public String getEmail() { return email; }
    public List<Stand> getStandsVisitados() { return standsVisitados; }

    // Setters para editar
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setEmail(String email) { this.email = email; }

    public void visitarStand(Stand stand) {
        if (!this.standsVisitados.contains(stand)) {
            this.standsVisitados.add(stand);
        }
    }

    public String mostrarDetalles() {
        return String.format("ID: %s | Nombre: %s | Email: %s",
                this.numeroIdentificacion, this.nombre, this.email);
    }
}
