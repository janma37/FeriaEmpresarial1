/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.feriaempresarial1;

/**
 *
 * @author juans
 */
import java.util.Scanner;

public class Aplicacion {
    private static FeriaManager manager = new FeriaManager();
    private static Scanner teclado = new Scanner(System.in);

    public static void main(String[] args) {
        // Precargar datos de ejemplo
        precargarDatos();
        
        System.out.println("Bienvenido al Sistema de Gestion de Feria Empresarial");
        int opcion;
        do {
            mostrarMenuPrincipal();
            opcion = leerOpcion();
            switch (opcion) {
                case 1: gestionarEmpresas(); break;
                case 2: gestionarStands(); break;
                case 3: gestionarVisitantes(); break;
                case 4: registrarVisitaComentario(); break;
                case 5: gestionarReportes(); break;
                case 0: System.out.println("Saliendo del sistema..."); break;
                default: System.out.println("Opcion no valida.");
            }
        } while (opcion != 0);
        teclado.close();
    }

    // --- MENUS ---
    private static void mostrarMenuPrincipal() {
        System.out.println("\n--- MENU PRINCIPAL ---");
        System.out.println("1. Gestionar Empresas");
        System.out.println("2. Gestionar Stands");
        System.out.println("3. Gestionar Visitantes");
        System.out.println("4. Registrar Visita y Comentario");
        System.out.println("5. Ver Reportes");
        System.out.println("0. Salir");
    }
    
    private static void gestionarEmpresas() {
        // Sub-menu para empresas (Crear, Editar, Eliminar, Listar, Asignar a Stand)
        System.out.println("\n-- Gestion de Empresas --");
        // Implementar logica de sub-menu aqui...
        System.out.println("Funcionalidad de ejemplo: Listando empresas...");
        manager.getEmpresas().forEach(e -> System.out.println(e.mostrarDetalles()));
    }
    
    private static void gestionarStands() {
        // Sub-menu para stands
        System.out.println("\n-- Gestion de Stands --");
        System.out.println("1. Listar todos los stands");
        System.out.println("2. Listar comentarios de un stand");
        System.out.print("Opcion: ");
        int opt = leerOpcion();
        if(opt == 1){
            manager.getStands().forEach(s -> System.out.println(s.mostrarDetalles()));
        } else if (opt == 2){
            System.out.print("Ingrese numero de stand: ");
            int numStand = leerOpcion();
            Stand stand = manager.buscarStand(numStand);
            if(stand != null) stand.mostrarComentarios();
            else System.out.println("Stand no encontrado.");
        }
    }
    
    private static void gestionarVisitantes() {
        // Sub-menu para visitantes
        System.out.println("\n-- Gestion de Visitantes --");
        System.out.println("Funcionalidad de ejemplo: Listando visitantes...");
        manager.getVisitantes().forEach(v -> System.out.println(v.mostrarDetalles()));
    }
    
    private static void registrarVisitaComentario() {
        System.out.println("\n-- Registrar Visita y Comentario --");
        System.out.print("ID del Visitante: ");
        String idVisitante = teclado.nextLine();
        System.out.print("Numero del Stand a visitar: ");
        int numStand = leerOpcion();
        System.out.print("Calificacion (1-5): ");
        int calificacion = leerOpcion();
        System.out.print("Comentario: ");
        String texto = teclado.nextLine();

        if (manager.registrarVisitaYComentario(idVisitante, numStand, calificacion, texto)) {
            System.out.println("Visita y comentario registrados exitosamente.");
        } else {
            System.out.println("Error: No se pudo registrar. Verifique los datos.");
        }
    }
    
    private static void gestionarReportes() {
        System.out.println("\n-- Menu de Reportes --");
        System.out.println("1. Reporte de Empresas y Stands");
        System.out.println("2. Reporte de Visitantes y Visitas");
        System.out.print("Opcion: ");
        int opt = leerOpcion();
        if (opt == 1) manager.generarReporteEmpresasYStands();
        else if (opt == 2) manager.generarReporteVisitantesYVisitas();
    }

    // --- UTILIDADES ---
    private static int leerOpcion() {
        try {
            return Integer.parseInt(teclado.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Entrada invalida. Intente de nuevo.");
            return -1;
        }
    }
    
    private static void precargarDatos() {
        // Empresas
        manager.registrarEmpresa("TecnoCorp", "Tecnologia", "contacto@tecnocorp.com");
        manager.registrarEmpresa("SaludVital", "Salud", "info@saludvital.co");
        // Stands
        manager.crearStand(101, "Pabellon A", "grande");
        manager.crearStand(102, "Pabellon A", "mediano");
        manager.crearStand(201, "Pabellon B", "pequeño");
        // Visitantes
        manager.registrarVisitante("Ana Gomez", "12345", "ana.g@mail.com");
        manager.registrarVisitante("Luis Parra", "67890", "luis.p@mail.com");
        // Asignaciones
        manager.asignarEmpresaAStand(1, 101); // TecnoCorp al Stand 101
        manager.asignarEmpresaAStand(2, 102); // SaludVital al Stand 102
    }
}